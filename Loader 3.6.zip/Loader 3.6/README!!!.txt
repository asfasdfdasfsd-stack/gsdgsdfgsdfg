1. OPEN Loader 3.5.exe 
2. Open game